PRIORIDADE 5 - Adicionar ao site um layout agradável para quem usa ter uma boa experiência.

**Observações técnicas**

**Requisito 16.**
