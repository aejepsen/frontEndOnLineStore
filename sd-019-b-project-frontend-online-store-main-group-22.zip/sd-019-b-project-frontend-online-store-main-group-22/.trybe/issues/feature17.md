**PRIORIDADE 5** - Faça um layout responsivo completo, para telas pequenas.

**Observações técnicas**

**Requisito 17.**
