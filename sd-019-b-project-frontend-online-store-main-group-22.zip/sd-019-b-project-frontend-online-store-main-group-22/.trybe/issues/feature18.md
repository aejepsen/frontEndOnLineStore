**PRIORIDADE 5** - Criar um seletor dropdown que permite a lista de produtos ser ordenada por maior e menor preço.

- [Tela principal - Ordenação por preço](https://github.com/my-org/my-repo/tree/master/wireframes/bonus_ordering.png)

**Observações técnicas**

**Requisito 18.**
